

// DELETE DATA
function deletedata(link){
    document.location.href = '?delete='+link;
}

// EDIT
const table = document.querySelector('table');
const editbtn = table.getElementsByClassName('edit');
const modal = document.getElementById('exampleModal');
const titleModal = document.getElementById('titleModal');
const btnModal = document.getElementById('btnModal');
const inputModal1= document.getElementById('pertanyaan');
const inputModal2 = document.getElementById('jawaban-input');


const cobaNavbar = document.querySelector('.coba-navbars');
console.log(cobaNavbar);


for(let i = 0; i <= editbtn.length; i++){

    editbtn[i].addEventListener('click',function(){
        //AJAX
        const id = editbtn[i].getAttribute('data-id');
        const ajax = new XMLHttpRequest();
        const url = '../admin/ajax.php?idData='+id;
    
        ajax.onreadystatechange = function(){
            if(ajax.readyState == 4 && ajax.status == 200){
                // change modal atribut
                titleModal.innerHTML = "Edit Data";
                btnModal.innerHTML = "Edit";
    
                // parsing data json
                const jsonFile = JSON.parse(this.responseText);
                

                console.log(jsonFile);
                // INPUT VALUE
                // inputModal1.setAttribute('value',jsonFile.pertanyaan);
                // inputModal2.setAttribute('value',jsonFile.jawaban);
            }
        }
    
        ajax.open('GET',url,true);
        ajax.send();
     
    });
}
// console.log(titleModal);
