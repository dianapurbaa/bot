// Display

const chat = document.querySelector('.wrapper');
const icon = document.querySelector('.icon-utama');

chat.style.display = 'none';
icon.addEventListener('click',function(){
    chat.style.display = "block";
    icon.style.display = 'none';
});

// EXIT BUTTON
const exit = document.querySelector('svg');

exit.onclick = function(){
    chat.style.display = 'none';
    icon.style.display = 'block'
}
